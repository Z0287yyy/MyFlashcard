Note: For the best performance and stability. MicroSD must be formatted with FAT32, cluster size 32KB

Firmware update method:
Run Update_FW4.gb as a game.  Press A as prompted. The screen will flicker in the upgrade progress, it is normal.   The progress will cost 10+ seconds. The screen goes normal when upgrade is done. Power off your console as prompted!!!  Not press the reset button!!!

Power up your console. Check the FW version in the HELP tab by press SELECT, if the FW version displaying FW0, you have to do the update progress again until the FW version change to FW4.  Full charged batteries will help to prevent the upgrade failing.


