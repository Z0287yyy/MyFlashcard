DSTWO iPlayer v1.1
1, Fixed the bug vertical bar appears when booting
2, Fixed the unzip bug on linux system caused white screen when booting

How to install: 
Download and unzip, then copy ��DSTWO PLAYER�� and ��_dstwoplug�� folders to the root of your microsd card.
Note: you can put media files anywhere you want.