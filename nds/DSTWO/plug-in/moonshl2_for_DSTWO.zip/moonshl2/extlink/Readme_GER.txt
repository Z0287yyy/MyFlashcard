
Sie k�nnen Programme festlegen, welche in MoonShell2 mit bestimmten Endungen verkn�pft werden sollen.
Selbst wenn Sie diese Funktion nicht l�schen, sollte der Ordner erhalten bleiben.

Der NDS-Dateiname legt fest, welche Datei ge�ffnet werden soll.
F�gen Sie zB eine Datei namens "ipk.nds" in diesen Ordner ein, so wird MoonShell2 automatisch Dateien mit der Endnung IPK �ber die Datei "ipk.nds" laden.
Sollten eine Datei "mp3.nds" oder "jpg.nds" anlegen, so wird die festgelegte Applikation die Priorit�t �bernehmen und den internen Player abl�sen.

Sollten Sie eine inkomitable Datei festlegen, wird diese Datei ganz normal aufgerufen.
Wird beispielsweise eine Datei "ReinMoon.nds" in "sav.nds" umbenannt und eingef�gt, und eine .sav Datei gege�ffnet so wird ReinMoon gestartet, nicht aber die save-Datei.

Es ist leicht, ExtendLink-kompitable Daten zu erstellen (ein simples Beispiel liegt bei).
F�r weitere Informationen sehen Sie in die Datei "moonshl2_extlink_for_developer.txt".
Desweiteren wird beschrieben, wie die Homebrew wieder beendet und zu MoonShell2 zur�ckgekehrt werden kann (dies ist etwas komplizierter).

~�bersetzt von Falco