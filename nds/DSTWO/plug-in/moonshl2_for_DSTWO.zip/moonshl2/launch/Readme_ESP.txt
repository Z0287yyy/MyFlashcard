﻿

Esta carpeta contiene las aplicaciones de "Accesorios".
Puede guardar hasta 5 aplicaciones NDS.
Puede borrar todo lo que hay dentro, pero no el archivo/lanzador.

~Traducido por Boriar