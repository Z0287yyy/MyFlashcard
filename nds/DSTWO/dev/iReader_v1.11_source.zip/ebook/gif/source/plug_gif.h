#ifndef __PLUG_GIF_H
#define __PLUG_GIF_H

#include <datatype.h>
#include <fs_api.h>
#include <display.h>
#include <image.h>

bool LoadGIF(FILE *FileHandle);
s32 GetWidth(void);
s32 GetHeight(void);
void GetBitmap24(u32 LineY,u8 *pBM);

extern int gif_read(const char *filename, dword * pwidth, dword * pheight, pixel **image_data, pixel * bgcolor);
extern int gif_read_in_zip( void *fp, dword * pwidth, dword * pheight, pixel ** image_data, pixel * bgcolor, t_image_fread readfn );


#endif //__PLUG_GIF_H
