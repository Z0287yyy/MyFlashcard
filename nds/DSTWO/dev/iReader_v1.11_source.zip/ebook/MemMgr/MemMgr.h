#undef  assert
#define assert( x )

#ifndef _MEMMGR_H
#define _MEMMGR_H

enum{
	PDF_MEM_ID		= 0,
	FT2_MEM_ID 		= 1,
	JPEG_MEM_ID 	= 2,
	JBIG2_MEM_ID 	= 3,
	MEM_ID_MAX
};


extern int mem_effective;

////-----------------------------------------
////�ڴ�й¶�����ر�������
////-----------------------------------------
typedef struct mem_s
{
	unsigned int size;
	unsigned int buffer;
	struct mem_s *next;
}MEM_ST;

extern int mem_con_init_all( void );
extern void mem_con_free_all( void );

#endif //_MEMMGR_H
