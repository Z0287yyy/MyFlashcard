#include "memory_png.h"
#include <MemMgr.h>
#include <DrvMemMgr.h>

#include <debugoff.h>

extern void *png_smalloc2( unsigned int n )
{
	void *p = malloc_pdf( n );
#if MEM_RECORD	
	if( mem_effective == 1 )
	{
		if( p )
				MEMM( n, p, malloc_pdf, PNG_MEM_ID );
	}
#endif
	return p;
}

extern void *png_srealloc2( void *p,unsigned int n )
{
	void *np = realloc_pdf(p, n);

#if MEM_RECORD	
	if( mem_effective == 1 )
	{
//		if( p != np )
		{
			MEMR( n, p, np, malloc_pdf, PNG_MEM_ID );
		}
	}
#endif
	
	return np;
}

extern void png_sfree2( void *p )
{
#if MEM_RECORD
	if( mem_effective == 1 )
	{
		MEMF( p, free_pdf, PNG_MEM_ID );
	}
#endif
	
	free_pdf(p);
}
