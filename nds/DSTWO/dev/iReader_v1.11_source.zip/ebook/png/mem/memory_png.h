#ifndef __MEMORY_PNG_H
#define __MEMORY_PNG_H

#define PNG_MEM_ID 0 //��Ϊpdf��png��û��ͬʱ���ã����Կ�����pdf����һ��ID

#undef  MEM_RECORD
#define MEM_RECORD		 0 //�Ƿ��¼�ڴ���ƣ������ͷţ����

extern void *png_smalloc2( unsigned int n );
extern void *png_srealloc2( void *p,unsigned int n );
extern void png_sfree2( void *p );

#if 1

#undef	png_smalloc
#define png_smalloc( n )   ( { png_smalloc2( n ); } )

#undef  png_srealloc
#define png_srealloc( p, n )  ( { png_srealloc2( p, n ); } )

#undef  png_sfree
#define png_sfree( p )     ({ png_sfree2( p ); })

#else

#undef	png_smalloc
#define png_smalloc( n )   ( { void *p = png_smalloc2( n );printf( "%s,%s,%d: %08X\n", __FILE__, __FUNCTION__, __LINE__, p ); p;  } )

#undef  png_srealloc
#define png_srealloc( p, n )  ( { void *np = png_srealloc2( p, n ); printf( "%s,%s,%d: %08X %08X\n", __FILE__, __FUNCTION__, __LINE__, p, np ); np;} )

#undef  png_sfree
#define png_sfree( p )     ({  png_sfree2( p ); printf( "%s,%s,%d: %08X\n", __FILE__, __FUNCTION__, __LINE__, p ); })

#endif

#endif //__MEMORY_PNG_H
