#ifndef __PNG_HEADFILE_H
#define __PNG_HEADFILE_H

#ifdef __cplusplus
extern "C" {
#endif	


#include "datatype.h"
#include "fs.h"

extern int png_read( const char *filename, dword *pwidth, dword *pheight, pixel **image_data, pixel *bgcolor );
extern int png_read_in_zip( void *fp, dword * pwidth, dword * pheight, pixel ** image_data, pixel * bgcolor, t_image_fread readfn );

#ifdef __cplusplus
}
#endif

#endif //__PNG_HEADFILE_H
