
#ifndef plug_png_interface_h
#define plug_png_interface_h

#include <datatype.h>
//#include "boolean.h"

extern /*"C"*/ void PNGINT_SetFunc_ConsolePrintf(U32 adr);
extern /*"C"*/ void PNGINT_SetFunc_safemalloc(U32 adr);
extern /*"C"*/ void PNGINT_SetFunc_safefree(U32 adr);

//extern /*"C"*/ b8 PNGINT_Init(int FileHandle);
extern /*"C"*/ void PNGINT_Free(void);

extern /*"C"*/ s32 PNGINT_GetWidth(void);
extern /*"C"*/ s32 PNGINT_GetHeight(void);

extern /*"C"*/ void PNGINT_GetNextLine(U8 *buf);

extern BOOL PNGINT_Init( const char *filename );

#endif

