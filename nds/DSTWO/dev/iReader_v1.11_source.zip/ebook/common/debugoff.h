//---------------------------------------------------------------------
#include <display.h>
//---------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------------
//��ӡ��ض���
//-----------------------------------------------------------------------------------------------------------------------------
#undef  INFO
#define INFO	 __FILE__, __FUNCTION__, __LINE__

#undef TD
#define TD()

#undef TD2
#define TD2()

#undef F
#define F(x,s...)

#undef F2
#define F2(x,s...)

#undef TR
#define TR()

#undef 	TA
#define TA()

#undef dprintf
#define dprintf(x,s... )

#undef  debug_dpf
#define debug_dpf( a, b )

#undef  dprintf2
#define dprintf2(x,s... )


#undef  STOP
#define STOP() { /*TD(); FLUSH;*/printf( "\n\n" );F( "The stage test is end!\n\n" ); }

#undef  ERRP
#define ERRP


#undef  skeyC
#define skeyC

#if !DEBUG_LHM
#define debug_printf( buffer, n, str )
#endif
