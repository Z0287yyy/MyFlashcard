#ifndef __DEBUGOTHER_H
#define __DEBUGOTHER_H

#include <uart.h>

//-----------------------------------------------------------------------------------------------------------------------------
//��ӡ��ض���
//-----------------------------------------------------------------------------------------------------------------------------
#undef  INFO
#define INFO	 __FILE__, __FUNCTION__, __LINE__

#undef  TD2
#define TD2()		printf( "%s,%s,%d\n", __FILE__, __FUNCTION__, __LINE__ );

#undef  F2
#define F2(x,s...) {printf("%s:%d  ",__FILE__,__LINE__); printf(x,##s);}

#undef  TR2
#define TR2()		{ printf( "\n\n" ); printf( "%s,%s,%d\n\n", __FILE__, __FUNCTION__, __LINE__ ); }

#undef  dprintf2
#define dprintf2(x,s... ) printf(x,##s)

#undef TA2
#if 1
#define TA2()\
{	\
  unsigned int reg_ra;\
  __asm__ __volatile__("or %0, $0, $ra"	\
                        : "=r" (reg_ra) \
                        :); \
  printf( ">>>>>>>%s,%d: ra= %08X\n", __FUNCTION__, __LINE__, reg_ra ); \
}
#else
#define TA2()
#endif

#endif //__DEBUGOTHER_H

