#ifndef __MACRO_H__
#define __MACRO_H__

#include <datatype.h>

// ���������ֵ
#if 0
#define KEY_UP                      BIT(6)      // ����
#define KEY_DOWN                    BIT(7)      // ����
#define KEY_LEFT                    BIT(5)      // ����
#define KEY_RIGHT                   BIT(4)      // ����

#define KEY_A                      	BIT(0)      // OK 
#define KEY_B                    	BIT(1)      // EIXT
                                   
#define KEY_SELECT					BIT(2)
#define KEY_START					BIT(3)
#define KEY_L					 	BIT(9)
#define KEY_R					 	BIT(8)

#define KEY_X					 	BIT(10)
#define KEY_Y					 	BIT(11)
#define KEY_TOUCH					BIT(12)
#define VK_LID						BIT(13)
#endif


// ������unicode��صĺ�
// ����ʡ�Ժ��ַ�
#define CHAR_SUSPENSION_POINTS		(0x2026)
#define BLANK_CHAR					(_T(' '))            // ���λ���õ��ַ�(�ո�)
#define UNKNOWN_CHAR				(0x007F)             // ����ʶ���ַ�����ʾΪ����
#define _T(X)						L##X
typedef wchar_t						UNC;                 // UNICODE�ַ�
typedef wchar_t*					LPUNC;               // UNICODE�ַ���ָ��
#ifndef IsDBCcase
#define IsDBCcase(c)				(c<0x0080)           // �ж�һ���ַ��Ƿ����ַ�
#endif 

 
 
#define  BGCOLOR					RGB24(0x00, 100, 100)


enum{
	X_TOO_LITTLE = BIT( 0 ),
	X_TOO_LARGE  = BIT( 1 ),
	Y_TOO_LITTLE = BIT( 2 ),
	Y_TOO_LARGE  = BIT( 3 ),
	X_INVALID	 = BIT( 4 ),
	Y_INVALID	 = BIT( 5 ),
};

enum{
	BTN_A = 0, 
	BTN_B,
	BTN_X,
};


//���ô��ڹرհ�ť����ϵͳ
enum{
	CLOSE_MIN_X = 210,
	CLOSE_MAX_X = 225,
	CLOSE_MIN_Y = 30,
	CLOSE_MAX_Y = 42,
	CLOSE_CENCTER_X = ( CLOSE_MAX_X + CLOSE_MIN_X ) / 2,
	CLOSE_CENCTER_Y = ( CLOSE_MAX_Y + CLOSE_MIN_Y ) / 2,
	CLOSE_DIFF = 8,
};

//������ǩ���ڰ�ť����ϵͳ
enum{
	BM_CLOSE_MIN_X = 190,
	BM_CLOSE_MAX_X = 200,
	BM_CLOSE_MIN_Y = 45,
	BM_CLOSE_MAX_Y = 55,
	BM_CLOSE_CENCTER_X = ( BM_CLOSE_MAX_X + BM_CLOSE_MIN_X ) / 2,
	BM_CLOSE_CENCTER_Y = ( BM_CLOSE_MAX_Y + BM_CLOSE_MIN_Y ) / 2,
	BM_CLOSE_DIFF = 5,
	
	BM_ABTN_MIN_X = 138,
	BM_ABTN_MAX_X = 149,
	BM_ABTN_MIN_Y = 132,
	BM_ABTN_MAX_Y = 143,
	
	BM_BBTN_MIN_X = 185,
	BM_BBTN_MAX_X = 196,
	BM_BBTN_MIN_Y = 132,
	BM_BBTN_MAX_Y = 143,
};

//������ǩ�������ڰ�ť����ϵͳ
enum{
	BMM_CLOSE_MIN_X = 238,
	BMM_CLOSE_MAX_X = 252,
	BMM_CLOSE_MIN_Y = 4,
	BMM_CLOSE_MAX_Y = 18,
	BMM_CLOSE_CENCTER_X = ( BMM_CLOSE_MAX_X + BMM_CLOSE_MIN_X ) / 2,
	BMM_CLOSE_CENCTER_Y = ( BMM_CLOSE_MAX_Y + BMM_CLOSE_MIN_Y ) / 2,
	BMM_CLOSE_DIFF = 7,
	
	BMM_ABTN_MIN_X = 61,
	BMM_ABTN_MIN_Y = 172,
	
	BMM_BBTN_MIN_X = 135,
	BMM_BBTN_MIN_Y = BMM_ABTN_MIN_Y,
	
	BMM_XBTN_MIN_X = 211,
	BMM_XBTN_MIN_Y = BMM_ABTN_MIN_Y,
};

//��ť����ϵͳ
enum{
	ABTN_MIN_X = 136,
	ABTN_MAX_X = 147,
	ABTN_MIN_Y = 141,
	ABTN_MAX_Y = 152,
	
	BBTN_MIN_X = 192,
	BBTN_MAX_X = 203,
	BBTN_MIN_Y = ABTN_MIN_Y,
	BBTN_MAX_Y = ABTN_MAX_Y,
};

#define SECONDS_PER_MINUTE 60
#define SECONDS_PER_HOUR 3600
#define SECONDS_PER_DAY 86400
#define SECONDS_PER_MONTH 2629743
#define SECONDS_PER_YEAR 31556926


enum{
	ERR_UNKNOWN = -1,
	ERR_NONE = 0,
	ERR_MEM_LACK = 2,
	ERR_MEM_INVALID,
	ERR_FORMAT,
	ERR_FORMAT_NOT_SUPPORTED,
	ERR_FILE_OPEN,
	ERR_FILE_RW,
	ERR_OTHER,
};//ͼƬ������󷵻���


//#define SEEK_SET    0
//#define SEEK_CUR    1
//#define SEEK_END    2

#define STR_DEFAULT_LEN 256

#define	TimeDly( n )

#define		utf8_ucs2( in, out )  utf8_to_ucs( out, 0x7FFFFFFF, in, 0x7FFFFFFF )

//----------------CodeType check--------------------------------------
#define CODETYPE_DEFAULT                              	0
#define CODETYPE_GBK                                  	1
#define CODETYPE_BIG5                                 	2
#define CODETYPE_SHIFTJIS                             	3
#define CODETYPE_UNICODE                              	4
#define CODETYPE_UTF8                                 	5
#define CODETYPE_UNICODE_BIGENDIAN     					6

#define GBKOFFSET         0x8140
#define BIG5OFFSET        0x8140
#define JIS0201OFFSET     0xA1
#define JIS0201LENGTH     63
#define JIS0208OFFSET     0x8140

typedef int CodeType;

//#define InitTimer( channel, msecond, timerhandle, arg )

#endif //__MACRO_H__
