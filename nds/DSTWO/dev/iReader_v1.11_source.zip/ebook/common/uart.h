#ifndef __UART_H
#define __UART_H

#include <console.h>
#include <display.h>

#define		printf		cprintf

#if DEBUG_LHM
void debug_printf( unsigned char *buffer, unsigned int n, const unsigned char *str );
void debug_printf2( pixel *buffer, unsigned int n, const unsigned char *str );
void debug_printf3( unsigned char *buffer, unsigned int n, const char *str, int line );
#endif

#endif //__UART_H
