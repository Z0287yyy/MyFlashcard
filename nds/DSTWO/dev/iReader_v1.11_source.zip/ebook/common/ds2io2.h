#ifndef __DIS2IO2_H
#define __DIS2IO2_H

#include <ds2io.h>

typedef struct rtc RTC;
typedef struct key_buf KEY_BUF;

#define		DS2_setBacklight( up_sw, down_sw )	ds2_setBacklight( (up_sw << 1) | (down_sw) )

#endif //__DIS2IO2_H
