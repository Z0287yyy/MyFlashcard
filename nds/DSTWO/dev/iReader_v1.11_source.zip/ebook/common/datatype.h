#ifndef _DATATYPE_H_
#define _DATATYPE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <types.h>
#include <stddef.h>


#define				COLOR_ADJUST				0


#ifndef byte
//#undef byte
////#define byte unsigned char
typedef unsigned char byte;
#endif

#ifndef word
typedef unsigned short int word;
#endif

#ifndef dword
typedef unsigned int dword;
#endif

#ifndef BYTE
typedef unsigned char BYTE;
#endif

#ifndef WORD
typedef unsigned short int WORD;
#endif

#ifndef DWORD
typedef unsigned int DWORD;
#endif


#ifndef BOOL
typedef int BOOL;
#endif

#ifndef bool
typedef int bool;
#endif

#ifndef  u8
#define  u8   unsigned char
#endif

#ifndef  U8
#define  U8   unsigned char
#endif

#ifndef U16
#define U16	unsigned short int
#endif

//#ifndef U16
//////#define U16	unsigned short int
//#endif

#ifndef u32
#define u32	unsigned int
#endif

#ifndef U32
#define U32	unsigned int
#endif

#ifndef u64
#define u64	unsigned long long int
#endif

#ifndef uchar
#define uchar	unsigned char
#endif

#ifndef UCHAR
#define UCHAR	unsigned char
#endif

#ifndef uint
//#define uint	unsigned int
#endif

#ifndef UINT
#define UINT	unsigned int
#endif

#ifndef ulong
typedef unsigned long long int ulong_t;
//#define ulong	unsigned long long int
#endif

#ifndef ULONG
////#define ULONG	unsigned long long int
#endif

#ifndef s8
#define s8	signed char
#endif

#ifndef s16
#define s16	signed short int
#endif

#ifndef s32
#define s32	signed int
#endif

#ifndef s64
#define s64	signed long long int
#endif

typedef     float                   f32;
typedef     double                  f64;

#define     vl                      volatile

typedef     vl U8                   vu8;
typedef     vl U16                  vu16;
typedef     vl U32                  vu32;
typedef     vl u64                  vu64;

typedef     vl s8                   vs8;
typedef     vl s16                  vs16;
typedef     vl s32                  vs32;
typedef     vl s64                  vs64;

typedef     vl f32                  vf32;
typedef     vl f64                  vf64;

#ifndef wchar_t
#undef wchar_t
//#define wchar_t int
//typedef int wchar_t;
#endif

#ifndef _wchar_t
typedef int _wchar_t;
#endif
/*
#ifndef u_char
typedef	unsigned char	u_char;
#endif

#ifndef u_short
typedef	unsigned short	u_short;
#endif

#ifndef u_int
typedef	unsigned int	u_int;
#endif

#ifndef u_long
typedef	unsigned long	u_long;
#endif

*/

#ifndef _uint8_t
typedef unsigned char _uint8_t;
#endif

#ifndef _uint16_t
typedef unsigned short int _uint16_t;
#endif


#ifndef _uint32_t
typedef unsigned int _uint32_t;
#endif

#ifndef _uint64_t
typedef unsigned long long int _uint64_t;
#endif

#ifndef int8
typedef	char int8;
#endif

#ifndef int16
typedef	short int16;
#endif


#ifndef int32
typedef	int int32;
#endif

#ifndef int64
typedef	signed long long int int64;
#endif

#ifndef uint8
typedef	unsigned char uint8;
#endif

#ifndef uint16
typedef	unsigned short int uint16;
#endif


#ifndef uint32
typedef	unsigned int uint32;
#endif

#ifndef uint64
typedef	unsigned long long int uint64;
#endif

#ifndef _size_t
////#define size_t unsigned int
typedef unsigned int _size_t;
#endif

#ifndef size_t
#define size_t unsigned int
#endif


#ifndef USHORT
#define USHORT unsigned short int
#endif

#ifndef _int8_t
//#undef  int8_t
//#define int8_t signed char
typedef signed char _int8_t;
#endif


#ifndef _int16_t
//#undef  int16_t
//#define int16_t signed short int
typedef signed int _int16_t;
#endif


#ifndef _int32_t
//#undef  int32_t
//#define int32_t signed int
typedef signed int _int32_t;
#endif

#ifndef _int64_t
typedef signed long long int _int64_t;
//#define int64_t signed long long int
#endif



#ifndef RESID
typedef int                 RESID;               // ��Դid��
#endif


#define SCREENREF   U16   //��ʾ��Ļ�ߴ����������

#define SYSTEM_FONT_HEIGHT 12

#undef	COLOR
#define COLOR      U16

#ifndef true
#define true 1
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef True
////#define True 1
#endif

#ifndef false
#define false 0
#endif

#ifndef False
#define False 0
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef NULL
#define NULL ((void *)0)
#endif

#ifndef null
#define null ((void *)0)
#endif

#ifndef INVALID
#define INVALID ((dword)-1)
#endif

#ifndef BIT
#define BIT(n) (1 << (n))
#endif

#ifndef min
#define min(a,b) (((a)<(b))?(a):(b))
#endif

#ifndef MIN
#define MIN(a,b) (((a)<(b))?(a):(b))
#endif

#ifndef MAX
#define MAX(a,b) ( ( (a) > (b) ) ? (a) : (b) )
#endif

#if COLOR_ADJUST //��ɫУ��

#ifndef RGB15
#define RGB15(r,g,b)  ( ( (r)<<10 ) | (g)<<5 | (b) | BIT(15) )
#endif

#ifndef RGB24
#define RGB24( r,g,b )  ( (r)<<16 | ((g)<<8) | (b) )
#endif

#else

#ifndef RGB15
#define RGB15(r,g,b)  ( (b)<<10 | (g)<<5 | (r) | BIT(15) )
#endif

#ifndef RGB24
#define RGB24( r,g,b )  ( (b)<<16 | (g)<<8 | (r) )
#endif

//RGB24��RGB15
#define RGB(r,g,b) ( (((pixel)(b)*31/255)<<10)|(((pixel)(g)*31/255)<<5)|((pixel)(r)*31/255)|BIT(15) )

#endif

#ifndef INVALID
#define INVALID ((dword)-1)
#endif

#ifndef EOF
#define EOF  -1
#endif

#define PATH_MAX2 256

#define MAKEWORD(a, b)      ((WORD)(((BYTE)((DWORD)(a) & 0xff)) | \
                            ((WORD) ((BYTE)((DWORD)(b) & 0xff))) << 8))
#ifndef offsetof
#undef  offsetof
#define offsetof(s, m) (unsigned long)(&(((s*)0)->m))
#endif

//#ifndef abs
//#define abs(a)              (((a) < 0) ? (-(a)) : (a))
//#endif


typedef struct 
{
	int Min_x;
	int Min_y;
	int Max_x;
	int Max_y;
}AJUST_KEY_BUF;

#define jmp_buf void*


////#include <bits/types.h>

#ifdef __cplusplus
}
#endif

#endif
