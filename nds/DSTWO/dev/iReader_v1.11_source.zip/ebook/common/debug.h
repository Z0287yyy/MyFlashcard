#ifdef __cplusplus
extern "C" {
#endif

#include <display.h>
#include <uart.h>

//----------------------------------------
//�������Կ��ƿ���
//----------------------------------------
//extern int 	debuguse;

//#undef   	DEBUGON
//#define  	DEBUGON  { debuguse = 1; }
//
//#undef   	DEBUGOFF
//#define  	DEBUGOFF  { debuguse = 0; }
//----------------------------------------
#define		pause_debug()


//-----------------------------------------------------------------------------------------------------------------------------
//��ӡ��ض���
//-----------------------------------------------------------------------------------------------------------------------------

#undef  INFO
#define INFO	 __FILE__, __FUNCTION__, __LINE__

#undef  TD
#define TD()		printf( "%s,%s,%d\n", __FILE__, __FUNCTION__, __LINE__ );

#undef  F
#define F(x,s...) {printf("%s:%d  ",__FILE__,__LINE__); printf(x,##s);}

#undef  TR
#define TR()		{ printf( "\n\n" ); printf( "%s,%s,%d\n\n", __FILE__, __FUNCTION__, __LINE__ ); }

#undef TA
#if DEBUG_LHM
#define TA()\
{	\
  unsigned int reg_ra;\
  __asm__ __volatile__("or %0, $0, $ra"	\
                        : "=r" (reg_ra) \
                        :); \
  printf( ">>>>>>>%s,%d: ra= %08X\n", __FUNCTION__, __LINE__, reg_ra ); \
}
#else
#define TA()
#endif


#undef  dprintf
#define dprintf(x,s... ) printf(x,##s)

extern void debug_dpfk( void *buf, unsigned int n, unsigned char *file, unsigned char *function, unsigned int line );
#undef  debug_dpf
#define debug_dpf( a, b ) \
				debug_dpfk( a, b, INFO )

#undef  STOP
#define STOP() { /*TD(); FLUSH;*/printf( "\n\n" );F( "The stage test is end!\n\n" ); while( 1 ); }

#undef  ERRP
#define ERRP F( "error = %d\n", error );


//---------------------------------------
//---------------------------------------
#undef  skeyC
#define skeyC


#if !DEBUG_LHM
#define debug_printf( buffer, n, str )
#endif


#ifdef __cplusplus
}
#endif

