/* vim:set ts=4 sw=4 cindent ignorecase enc=gbk: */

#include "common/datatype.h"

extern dword html_to_text(char *string, dword size, BOOL stripeol);
