#ifndef __MEMORY_FT2_H
#define __MEMORY_FT2_H

extern void *ft_smalloc2( unsigned int n );
extern void *ft_srealloc2( void *p,unsigned int n );
extern void ft_sfree2( void *p );

#if 1

#undef	ft_smalloc
#define ft_smalloc( n )   ( { ft_smalloc2( n ); } )

#undef  ft_srealloc
#define ft_srealloc( p, n )  ( { ft_srealloc2( p, n ); } )

#undef  ft_sfree
#define ft_sfree( p )     ({ ft_sfree2( p ); })

#else

#undef	ft_smalloc
#define ft_smalloc( n )   ( { printf( "%s,%s,%d\n", __FILE__, __FUNCTION__, __LINE__ ); ft_smalloc2( n ); } )

#undef  ft_srealloc
#define ft_srealloc( p, n )  ( { printf( "%s,%s,%d\n", __FILE__, __FUNCTION__, __LINE__ ); ft_srealloc2( p, n ); } )

#undef  ft_sfree
#define ft_sfree( p )     ({ printf( "%s,%s,%d\n", __FILE__, __FUNCTION__, __LINE__ ); ft_sfree2( p ); })

#endif

#endif //__MEMORY_FT2_H
