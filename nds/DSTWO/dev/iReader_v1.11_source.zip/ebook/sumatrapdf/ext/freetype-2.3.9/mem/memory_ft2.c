#include "memory_ft2.h"
#include <MemMgr.h>
#include <DrvMemMgr.h>

#include <debugoff.h>

#undef  MEM_RECORD
#define MEM_RECORD		 1 //�Ƿ��¼�ڴ���ƣ������ͷţ����

extern void *ft_smalloc2( unsigned int n )
{
	void *p = malloc_pdf( n );
#if MEM_RECORD	
	if( mem_effective == 1 )
	{
		if( p )
				MEMM( n, p, malloc_pdf, FT2_MEM_ID );
	}
#endif
	return p;
}

extern void *ft_srealloc2( void *p,unsigned int n )
{
	void *np = realloc_pdf(p, n);

#if MEM_RECORD	
	if( mem_effective == 1 )
	{
		if( p != np )
		{
			MEMR( n, p, np, malloc_pdf, FT2_MEM_ID );
		}
	}
#endif
	
	return np;
}

extern void ft_sfree2( void *p )
{
#if MEM_RECORD
	if( mem_effective == 1 )
	{
		MEMF( p, free_pdf, FT2_MEM_ID );
	}
#endif
	
	free_pdf(p);
}
