/* vim:set ts=4 sw=4 cindent ignorecase enc=gbk: */

#ifndef _CTRL_H_
#define _CTRL_H_

#include <ds2io2.h>
#include <datatype.h>

#define KEYREPEAT 			5
#define KEYREPEAT_CON	 	10

extern dword ctrl_read();
extern void UpKeyEntry( unsigned int key );
extern void DownKeyEntry( unsigned int key );
extern U16 ctrl_waitany();
extern struct key_buf ctrl_waitany2();
extern KEY_BUF ctrl_waitmove();
extern void ctrl_waitrelease( U16 key );
extern KEY_BUF ctrl_nowait( RTC *time );
extern KEY_BUF ctrl_nowait2( void );
extern void ctrl_waitrelease_anykey( void );
extern BOOL Proc_Supend( U16 key );
extern BOOL Proc_ExitSys( U16 key );
extern void Proc_SysKeyCheck( U16 key );

#endif
