/* vim:set ts=4 sw=4 cindent ignorecase enc=gbk: */

#ifndef _BG_H_
#define _BG_H_

#include <datatype.h>
//#include "fs.h"
#include "gdi.h"
#include <config_ebook.h>


extern void bg_load();
extern void bg_screen_load();
extern BOOL bg_display( SCREEN_ID engine );
extern void bg_cancel();
extern void bg_cache();
extern void bg_restore();

extern const pixel FLBgColor[2];
extern const pixel FL_LineRecty[10];
extern const pixel FL_LineFonty[10];
//extern U32 File_Dir_x;

extern pixel RetLOGO[FL_MINILOGO_W * FL_MINILOGO_H];
extern pixel FolderLOGO[FL_MINILOGO_W * FL_MINILOGO_H];
extern pixel TxtLOGO[FL_MINILOGO_W * FL_MINILOGO_H];
extern pixel PdfLOGO[FL_MINILOGO_W * FL_MINILOGO_H];
extern pixel PicLOGO[FL_MINILOGO_W * FL_MINILOGO_H];
extern pixel ZipLOGO[FL_MINILOGO_W * FL_MINILOGO_H];
extern pixel UnknowLOGO[FL_MINILOGO_W * FL_MINILOGO_H];
extern pixel SlideLOGO[FL_SLIDE_W * FL_SLIDE_H];
extern pixel FL_VRAM[FL_LINE_W*FL_LINE_H*MAX_ITEM_LINE * 3];

extern pixel bg_start_up[SCREEN_W * SCREEN_H];
extern pixel bg_start_down[SCREEN_W * SCREEN_H];

extern int notice_exit_font_x;

#endif
