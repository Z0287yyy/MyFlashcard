#ifndef __LANGUAGE_
#define __LANGUAGE_

#include <config_ebook.h>
#include <datatype.h>
#include <text.h>

#if 0
enum{
	LANG_INDEX_EN = 0,
	LANG_INDEX_CN,
	LANG_INDEX_TW,
	LANG_INDEX_JP,
};
#else

extern int LANG_INDEX_EN;
extern int LANG_INDEX_CN;
extern int LANG_INDEX_TW;
extern int LANG_INDEX_JP;

#endif

#if 0
enum{
	LANG_OK_ID = 0,
	LANG_CANCEL_ID,
	LANG_NOTICE_ID,
	LANG_HELP_ID,
	LANG_EXIT_ID,
	LANG_EXITIREADER_ID,
	
	LANG_CATALOG_ALL_ID,
	LANG_CATALOG_BOOK_ID,
	LANG_CATALOG_PICTURE_ID,
	
	LANG_FONT_TITLE_ID,
	LANG_FONTSIZE_ID,
	LANG_ROWSPACE_ID,
	LANG_WORDSPAC_ID,
	
	LANG_STYLE_MENU_ID,
	
	LANG_READMODE_MENU_ID,
	LANG_READMODE_TITLE_ID,
	LANG_READMODE_ITEM1,
	LANG_HORIZONTAL_ID,
	LANG_VERTICAL_ID,
	LANG_UPPERSCREEN_ID,
	LANG_LOWERSCREEN_ID,
	LANG_DOUBLECREEN_ID,
	
	LANG_BRIGHTNESSSETTINGS_ID,
	LANG_BRIGHTNESS_MENU_ID,
	
	LANG_JUMP_MENU_ID,
	LANG_JUMP_TITLE_ID,
	LANG_JUMP_ITEM0_ID,
	
	LANG_BM_MENU_ID,
	LANG_BM_TITLE_ID,
	LANG_ADDBM_ID,
	LANG_VIEWBMLIST_ID,
	LANG_BM_EMPTY_ID,
	LANG_BM_JUMP_ID,
	LANG_BM_RETURN_ID,
	LANG_DELETE_ID,
	LANG_DELETEALL_ID,
	LANG_SAVEBM_ID,
	LANG_SAVEBM_OK_ID,
	
	LANG_HELP_MENU_ID,
	
	LANG_ID_COUNT,
};
#else

extern U32 cur_lang_index;//��ǰʹ����������

#define LANG_ID_COUNT 107

extern int  LANG_OK_ID;
extern int  LANG_CANCEL_ID;
extern int  LANG_NOTICE_ID;
extern int  LANG_HELP_ID;
extern int  LANG_EXIT_ID;
extern int  LANG_SELECT_ID;
extern int  LANG_EXITIREADER_ID;
extern int  LANG_EXITITXT_ID;
extern int  LANG_OPENFILEERROR_ID;
extern int  LANG_FILEEMPTY_ID;
extern int  LANG_FILEENCODE_ID;
	
extern int  LANG_CATALOG_ALL_ID;
extern int  LANG_CATALOG_BOOK_ID;
extern int  LANG_CATALOG_PICTURE_ID;
	
extern int  LANG_FONT_MENU_ID;
extern int  LANG_FONT_TITLE_ID;
extern int  LANG_FONTSIZE_ID;
extern int  LANG_ROWSPACE_ID;
extern int  LANG_WORDSPAC_ID;
extern int  LANG_FONTCOLOR_ID;
extern int  LANG_FONTBGCOLOR_ID;
	
extern int  LANG_STYLE_MENU_ID;
extern int  LANG_STYLE_TITLE_ID;
	
extern int  LANG_READMODE_MENU_ID;
extern int  LANG_READMODE_TITLE_ID;
extern int  LANG_READMODE_ITEM0_ID;
extern int  LANG_READMODE_ITEM1_ID;
extern int  LANG_HORIZONTAL_ID;
extern int  LANG_VERTICAL_ID;
extern int  LANG_UPPERSCREEN_ID;
extern int  LANG_LOWERSCREEN_ID;
extern int  LANG_DOUBLECREEN_ID;
	
extern int  LANG_BRIGHTNESS_MENU_ID;
extern int  LANG_BRIGHTNESS_TITLE_ID;
extern int  LANG_BRIGHTNESS_ID;

extern int LANG_LANGUAGE_ID;
extern int LANG_LANG0_ID;
extern int LANG_LANG1_ID;
extern int LANG_LANG2_ID;
extern int LANG_LANG3_ID;
extern int LANG_BRIGHTNESS_NOTE_ID;
	
extern int  LANG_JUMP_MENU_ID;
extern int  LANG_JUMP_TITLE_ID;
extern int  LANG_JUMP_ITEM0_ID;
	
extern int  LANG_BM_MENU_ID;
extern int  LANG_BM_TITLE_ID;
extern int  LANG_ADDBM_ID;
extern int  LANG_VIEWBMLIST_ID;
extern int  LANG_DELETE_ID;
extern int  LANG_DELETEALL_ID;
extern int  LANG_BM_JUMP_ID;
extern int  LANG_BM_RETURN_ID;
extern int  LANG_BM_DEL_ID;
extern int  LANG_BM_EMPTY_ID;
extern int  LANG_SAVEBM_ID;
extern int  LANG_SAVEBM_OK_ID;
	
extern int  LANG_HELP_MENU_ID;
extern int  LANG_HELP_TITLE_ID;

extern int	LANG_SIZE_ID;
extern int	LANG_FILESIZE_ID;
extern int	LANG_ZOOM_ID;

extern int	LANG_ORIGSIZE_ID;
extern int	LANG_ADAPTH_ID;
extern int	LANG_ADAPTW_ID;
extern int	LANG_IMG_LOAD_FAIL_ID;
extern int	LANG_IMG_ZOOM_FAIL_ID;
extern int	LANG_IMG_ROTATE_FAIL_ID;
extern int	LANG_IMG_FAIL_REASON_ID;
extern int	LANG_WFORMAT_ID;
extern int	LANG_MEMLACK_ID;
extern int	LANG_ERRFILEOPEN_ID;
extern int	LANG_ERRFILERW_ID;
extern int	LANG_UNKNOWN_REASON_ID;

extern int	LANG_FBH_TITLE_ID;
extern int	LANG_FBH_UP_ID;
extern int	LANG_FBH_DOWN_ID;
extern int	LANG_FBH_LEFT_ID;
extern int	LANG_FBH_RIGHT_ID;
extern int	LANG_FBH_L_R_ID;
extern int	LANG_FBH_A_ID;
extern int	LANG_FBH_B_ID;
extern int	LANG_FBH_SELECT_ID;
extern int	LANG_FBH_START_ID;


extern int	LANG_TXTRH_TITLE_ID;
extern int	LANG_TXTRH_UP_ID;
extern int	LANG_TXTRH_DOWN_ID;
extern int	LANG_TXTRH_LEFT_ID;
extern int	LANG_TXTRH_RIGHT_ID;
extern int	LANG_TXTRH_RLEFT_ID;
extern int	LANG_TXTRH_RRIGHT_ID;
extern int	LANG_TXTRH_X_ID;
extern int	LANG_TXTRH_Y_ID;
extern int	LANG_TXTRH_B_ID;

extern int	LANG_PBH_TITLE_ID;
extern int	LANG_PBH_UP_ID;
extern int	LANG_PBH_DOWN_ID;
extern int	LANG_PBH_LEFT_ID;
extern int	LANG_PBH_RIGHT_ID;
extern int	LANG_PBH_L_ID;
extern int	LANG_PBH_R_ID;
extern int	LANG_PBH_AUP_Y_ID;
extern int	LANG_PBH_ADOWN_X_ID;
extern int	LANG_PBH_ALEFT_ID;
extern int	LANG_PBH_ARIGHT_ID;
extern int	LANG_PBH_AL_ID;
extern int	LANG_PBH_AR_ID;

extern int	LANG_PDFH_TITLE_ID;
extern int	LANG_PDF_PAGE_ID;
extern int	LANG_PDF_CURPAGE_ID;
extern int	LANG_PDFH_L_ID;
extern int	LANG_PDFH_R_ID;
extern int	LANG_PDFH_AL_ID;
extern int	LANG_PDFH_AR_ID;


#endif

extern char *lang_item[LANG_ID_COUNT];
extern U32 cur_lang_index;
extern const char lang_path_tab[SUPPORT_LANG_MAX_COUNT][3];
extern const char default_lang_str;
extern const char *lang_ok;
extern const char *lang_cancel;
extern const char *lang_Notice;
extern const char *lang_Help;
extern const char *lang_Exit;

//int language_read( const char *filename, char ** ppTxtData, int *len );
int language_find( const char *srcstr, const char *cmpstr_seg, const char *cmpstr_item, char **ppdststr );
int language_find_item( const char *srcstr, const char *cmpstr_item, char **ppdststr );
//int language_find_item( const char *srcstr, const char *cmpstr_item, char **ppdststr,  const char *defaultstr );
void language_load( void );
void language_load_ucs2( void );
int GetlanguageCodingType( void );

int language_find_seg_ucs2( const char *srcstr, const char *cmpstr_seg, char **pptr_seg, U32 *len_seg, U32 lang_len );
int language_find_item_In_seg_ucs2( const char *ptr_seg, U32 len_seg, const char *cmpstr_item, char **ppdststr );

void language_load_utf8( void );
void language_free();
int Curlang_config_save( int cur_lang_index );



//#define	language_find_seg( srcstr, cmpstr_seg, ppdststr ) language_find_item( srcstr, cmpstr_item, ppdststr ) 

#endif //__LANGUAGE_
