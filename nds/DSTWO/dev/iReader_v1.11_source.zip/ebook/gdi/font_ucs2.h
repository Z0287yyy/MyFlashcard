#ifndef __FONT_UCS2_H
#define __FONT_UCS2_H

#include <datatype.h>
#include <config_ebook.h>
#include <display.h>
#include <gdi.h>
#include <ds2io2.h>

extern int TestValue;

void UnicodeDisplayJP( U16 words, int base_x, int base_y, pixel fontcolor, SCREEN_ID engine );
int ProcFontUcs2_SetCallBack( int fontCoding_type );


#endif //__FONT_UCS2_H
