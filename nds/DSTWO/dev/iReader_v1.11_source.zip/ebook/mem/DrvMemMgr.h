#ifndef __DrvMemMgr_H
#define __DrvMemMgr_H

#include <ds2_malloc.h>

extern void *zmalloc( unsigned int nbytes );
extern void *malloc_pdf( unsigned int nbytes );
extern void *zmalloc_pdf( unsigned int nbytes );
extern void *calloc_pdf( unsigned nelem, unsigned elsize );
extern void *realloc_pdf( void *address,unsigned int nbytes);
extern void free_pdf( void *buffer );

#define memalign_pdf( align, size ) alignAlloc_pdf( align, size )

#define memalign( align, size )   malloc( align * size )

#endif //__DrvMemMgr_H
