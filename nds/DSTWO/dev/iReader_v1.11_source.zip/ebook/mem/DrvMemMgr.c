#include <datatype.h>
#include <DrvMemMgr.h>
#include <ds2_malloc.h>


extern void *zmalloc( unsigned int nbytes )
{
	void *buffer = (void*)malloc( nbytes );
	if( !buffer )return NULL;
	memset( buffer, 0, nbytes );

	return buffer;
}

extern void *malloc_pdf( unsigned int nbytes )
{
	void *p = malloc( nbytes );
	return p;
}

extern void *zmalloc_pdf( unsigned int nbytes )
{
	void *p = zmalloc( nbytes );
	return p;
}


extern void *calloc_pdf( unsigned int nelem, unsigned int elsize )
{
	void *p = calloc( nelem, elsize );
	return p;
}

extern void *realloc_pdf( void *address,unsigned int nbytes)
{
	void *p = realloc( address, nbytes );
	return p;
}

extern void free_pdf( void *buffer )
{
	free( buffer );
}
