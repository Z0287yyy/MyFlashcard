#ifndef __BOOKMARKSET_H
#define __BOOKMARKSET_H

#include "common/datatype.h"
#include <gdi.h>
#include <msgbox.h>
#include <bookmark.h>

enum{
	ADD_BM = 0,
	LOOK_BM,
};
enum{
	DEL_BM = 0,
	DELALL_BM,
};

struct _Bookmark
{
	U32 BookmarkCount;
	U8  CurFontSize;
	U32 row;
} __attribute__ ((packed));
typedef struct _Bookmark t_Bookmark, *p_Bookmark;

typedef struct {
	U32 row;
	char *bm_name;
}BMSETTINGS_s;

typedef struct{
	U32 row;
	t_bm_time bmtime;
}t_bookmark_dis,*p_bookmark_dis;

int BookmarkManage( BMSETTINGS_s *bmsettings, BOOL needp_LR );
int Bookmak_list( char *bookmarkname );
void DisplayPercentage( U16 percentage, int x, int y, pixel color, SCREEN_ID engine );
int Bookmark_DelInterface( p_bookmark bm, U32 index, int SelectBar);
void BookmarkManageDraw( U16 mask,  U16 maskFocus );
void BookmarkDelDraw( U16 mask,  U16 maskFocus );

//#define		BookmarkManage()	Bookmark_Interface( 0, 0, ADD_BM )

#endif //__BOOKMARKSET_H
