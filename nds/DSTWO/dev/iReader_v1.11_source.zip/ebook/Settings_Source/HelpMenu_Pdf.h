#ifndef __HELPMENU_PDF_H
#define __HELPMENU_PDF_H


void HelpMenuDisplay_Pdf( void );


#endif //__HELPMENU_PDF_H
