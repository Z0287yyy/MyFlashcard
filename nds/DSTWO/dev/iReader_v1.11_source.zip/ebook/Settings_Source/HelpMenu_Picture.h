#ifndef __HELPMENU_PICTURE_H
#define __HELPMENU_PICTURE_H


void HelpMenuDisplay_Picture( void );


#endif //__HELPMENU_PICTURE_H
