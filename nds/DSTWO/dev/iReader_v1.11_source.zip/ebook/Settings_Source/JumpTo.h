#ifndef  __JUMPTO_H
#define  __JUMPTO_H

#include <datatype.h>

#define		JUMPTO_FONTSPACE		3

U32 JumpToPercentage( U32 *Percentage );
void JumpToDraw( U16 mask,  U16 maskFocus, U8 *ItemValue, U8 ShiftBit );
void JumpTo_Language_Load( void );

#endif  //__JUMPTO_H
