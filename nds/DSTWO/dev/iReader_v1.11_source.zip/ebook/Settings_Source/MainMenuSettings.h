#ifndef __READINGSETTINGS_
#define	__READINGSETTINGS_

#include <datatype.h>
#include <gdi.h>
#include <ds2io2.h>

#include <FontSet.h>
#include <StyleSet.h>
#include <ReadingMode.h>
#include <BacklightSet.h>
#include <BookmarkSet.h>
#include <JumpTo.h>


//MenuSettings��������ֵ��λ����
enum {
	bmFONTSIZE 			=			BIT( 0 ),
	bmROWSPACE 			=			BIT( 1 ),
	bmFONTCOLOR			=			BIT( 2 ),
	bmSTYLE				=			BIT( 3 ),
	bmBOOKMARK			=			BIT( 4 ),
	bmJUMPTO			=			BIT( 5 ),
	bmBACKLIGHT			=			BIT( 6 ),
	bmBRIGHTNESS		=			BIT( 7 ),
	bmVERTREAD			=			BIT( 8 ),
	bmSCREENSELECT		=			BIT( 9 ),
	bmWORDSPACE			=			BIT( 10 ),
	bmFONTBGCOLOR		=			BIT( 11 ),
	bmLANGUAGE			=			BIT( 12 ),
};

enum{
	BACKWARD = 0XFFFFFFFE,//-2
	FORWARD = 0XFFFFFFFF,//-1
};

typedef struct{
	int x;
	int y;
}POS;

typedef struct{
	FONTSET_s Font;
//	STYLESET_s Style;
	int StyleIndex;
	t_read ReadMode;
	BACKLIGHT_s  backlight;
	U32 Percentage;
	BMSETTINGS_s bmsettings;
}MENUSETTINGS_s;

//extern  U16  Percentage;

U32 MenuSettings( MENUSETTINGS_s *settings );
BOOL DrawProgress( U16  percentage, int x, int y, SCREEN_ID engine );
int CheckValidxy(  AJUST_KEY_BUF AjustKey, KEY_BUF inputkey );
void DrawSettingMenuBar( U16 mask,  U16 maskFocus );
void MenubarStr_Init();

#endif //__READINGSETTINGS_
