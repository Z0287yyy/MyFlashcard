#ifndef __HELPMENU_TEXT_H
#define __HELPMENU_TEXT_H

#include <datatype.h>

U32 HelpMenuDisplay_Text( BOOL need_bak, BOOL IsModeDialog );


#endif //__HELPMENU_TEXT_H
