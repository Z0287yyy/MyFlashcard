#ifndef __EXITMESSAGEBOX_
#define __EXITMESSAGEBOX_

#include <datatype.h>

BOOL  ExitMessage();

#endif //__EXITMESSAGEBOX_
