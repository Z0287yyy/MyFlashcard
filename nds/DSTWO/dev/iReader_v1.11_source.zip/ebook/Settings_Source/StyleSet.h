#ifndef __STYLESET
#define __STYLESET

typedef struct{
	pixel fcolor;//������ɫ
	pixel bcolor;//������ɫ
}STYLESET_s;

extern const STYLESET_s Style[10];
extern pixel *StyleBuf;
extern U32 neeprlogo;

U32 StyleSet( int  *StyleIndex );
void StyleDraw( U32 mask, U32 maskFocus );

#endif //__STYLESET
