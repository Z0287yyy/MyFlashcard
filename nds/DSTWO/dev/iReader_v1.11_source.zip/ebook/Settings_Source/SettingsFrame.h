#ifndef __SETTINGSFRAME_
#define __SETTINGSFRAME_

#include <datatype.h>
#include <display.h>
#include <config_ebook.h>

extern pixel LArrow[MENU_ARROW_LR_W * MENU_ARROW_LR_H];
extern pixel RArrow[MENU_ARROW_LR_W * MENU_ARROW_LR_H];
extern pixel MenuBarBg[MENU_ITEM_BAR_LOGO_W * MENU_ITEM_BAR_LOGO_H];;

void DrawSettingsFrame( BOOL needp_LR );



#endif //__SETTINGSFRAME_
