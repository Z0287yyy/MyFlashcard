#ifndef __MSGBOX
#define	__MSGBOX

#include <datatype.h>

//#define		RET_MB_OK			1
//#define   	RET_MB_CANCEL		2
//#define		RET_MB_ABORT		3
//#define		RET_MB_RETRY		4
//#define		RET_MB_IGNORE		5
//#define		RET_MB_YES			6
//#define		RET_MB_NO			7

typedef enum  {
	MB_OK 		= 0X0001,
	MB_CANCEL 	= 0X0002,
	MB_YES 		= 0X0004,
	MB_NO 		= 0X0008,
	MB_SELECT	= 0X0010
}DIALOGTYPE;

enum{
	LEFT_ALIGN = 0,
	CENTER_ALIGN,
	RIGHT_ALIGN,
};

U32 MessageBox( const char *title, const char *msg );
int DrawMessageBox( const char *title, int title_align, const char *msg, SCREEN_ID engine, U32 dialogtype, BOOL IsModeDialog );
int DrawMessageBoxFrame( void );

#endif //__MSGBOX
