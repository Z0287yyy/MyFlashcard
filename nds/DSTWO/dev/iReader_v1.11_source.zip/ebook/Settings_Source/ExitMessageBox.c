#include <ExitMessageBox.h>
#include <datatype.h>
#include <config_ebook.h>
#include <image.h>
#include <fs.h>
#include <display.h>
#include <mystring.h>
#include <gdi.h>
#include <Macro.h>
#include <conf.h>
#include <DrvMemMgr.h>
#include <ds2io2.h>
#include <ctrl.h>
#include <conf.h>
#include <msgbox.h>
#include <ds2io2.h>
#include <scene.h>
#include <scene_text.h>
#include <language.h>
#include <debugoff.h>

BOOL  ExitMessage()
{
	int result;
	pixel VramBuffer[SCREEN_W*SCREEN_H];

	SaveVram( VramBuffer, DOWN_SCREEN );
	
	result = DrawMessageBox( lang_Notice, CENTER_ALIGN, lang_item[LANG_EXITIREADER_ID], DOWN_SCREEN, MB_OK | MB_CANCEL, true );

	if( result == 1 )
	{
		config.bookfontsize = scene_get_book_fontsize( bookfontindex );
		TurnOn_up();//����������
		conf_save( &config );//��������
	}

	LoadVram( VramBuffer, DOWN_SCREEN );
	Flush( DOWN_SCREEN );
	return result;
}