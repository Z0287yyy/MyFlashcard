#ifndef  __READINGMODE_
#define  __READINGMODE_

#include <datatype.h>
#include <conf.h>

extern int ReadingMode;
extern SCREEN_USE ScreenUse;

enum{
	READINGMODE = 0,
	BACKLIGHT
};

typedef struct {
	dword vertread;
	SCREEN_USE ScreenUse; 
}t_read;


U32 ReadingModeSet( t_read *ReadMode );


void ReadingModeSetDraw( U16 mask,  U16 maskFocus, const char **ItemValue );
void ReadingMode_Language_Load( void );



#endif  //__READINGMODE_
