#ifndef  __BACKLIGHTSET_
#define  __BACKLIGHTSET_

#include <datatype.h>
#include <conf.h>
//enum{
//	READINGMODE = 0,
//	BACKLIGHT
//};

enum{
	BRIGHTNESSVALUE_MIN	 = 0,
	BRIGHTNESSVALUE_MAX	 = 3
};

typedef struct{
	U8	 brightness;
	U8	 BacklightUp;
	U8	 BacklightDown;
}BACKLIGHT_s;


enum{
	OFF = 0,
	ON = 1,
};

U32 BacklightSet( BACKLIGHT_s *backlight );
void BacklightSetDraw( U16 mask,  U16 maskFocus, const byte **ItemValue );
void BacklightSet_Language_Load( void );

#endif  //__BACKLIGHTSET_
