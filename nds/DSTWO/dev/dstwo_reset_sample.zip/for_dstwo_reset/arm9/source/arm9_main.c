#include <nds.h>

#include <nds/registers_alt.h>
#include "../../share/ipctool.h"

void zeroMemory(void* addr,int count)
{
    static u32 intidata;
    intidata=0;

    swiFastCopy( (void*)(&intidata), addr, (count>>2) | COPY_MODE_WORD | COPY_MODE_FILL);
}

void resetARM9Memory()
{
  	int i;
    // DMA
    for (i=0; i<4; i++) 
    {
        DMA_CR(i) = 0;
        DMA_SRC(i) = 0;
        DMA_DEST(i) = 0;
        TIMER_CR(i) = 0;
        TIMER_DATA(i) = 0;
    }

    // VIDEO
    // trun on vram banks for clear
    VRAM_CR = 0x80808080;
    // clear video palette
    zeroMemory( PALETTE, 2048 );//PALETTE[0] = RGB15(1,1,1);
    zeroMemory( PALETTE_SUB, 2048 );
    // clear video object attribution memory
    zeroMemory( OAM, 2048 );
    zeroMemory( OAM_SUB, 2048 );
    // clear video object data memory
    zeroMemory( SPRITE_GFX, 128 * 1024 );
    zeroMemory( SPRITE_GFX_SUB, 128 * 1024 );
    // clear main display registers
    zeroMemory( (void*)0x04000000, 0x56 );
    // clear sub display registers
    zeroMemory( (void*)0x04001000, 0x56 );
    // clear vram
    zeroMemory( VRAM, 656 * 1024 );

    // clear video registers
    REG_DISPCNT = 0;
    REG_DISPCNT_SUB = 0;
    VRAM_A_CR = 0;
    VRAM_B_CR = 0;
    VRAM_C_CR = 0;
    VRAM_D_CR = 0;
    VRAM_E_CR = 0;
    VRAM_F_CR = 0;
    VRAM_G_CR = 0;
    VRAM_H_CR = 0;
    VRAM_I_CR = 0;
    VRAM_CR   = 0x00000000;
    POWER_CR  = 0x820F; // turn on all engines

    // Interrupt
    REG_IME = 0;
    REG_IE = 0;
    REG_IF = ~0;

    for (i=0; i<4; i++) 
    {
        DMA_CR(i) = 0;
        DMA_SRC(i) = 0;
        DMA_DEST(i) = 0;
        TIMER_CR(i) = 0;
        TIMER_DATA(i) = 0;
    }

}


void resetAndLoop()
{

    REG_IME = 0;
    REG_IE = 0;
    REG_IF = ~0;
    WAIT_CR |= (0x8080);  // ARM7 has access to GBA cart
    IPC_ARM9 = IPC_MSG_ARM7_REBOOT;
    while( 1 ) 
    {
        swiDelay(100);
        clr_cache(&resetAndLoop,0x1000);
    }
}


int main(void)
{
    REG_IME = 0;
    REG_IE = 0;
    REG_IF = ~0;
    while( IPC_ARM9 != IPC_MSG_ARM7_READY ) 
    {
        swiDelay(0);
    }
		resetARM9Memory();
		resetAndLoop();	
		return true;
}
