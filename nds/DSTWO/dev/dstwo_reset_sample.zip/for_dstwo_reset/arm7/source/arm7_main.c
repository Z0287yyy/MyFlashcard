//////////////////////////////////////////////////////////////////////
// Demo1 ARM7 Code - Based on an example shipped with NDSLIB.
// Chris Double (chris.double@double.co.nz)
//////////////////////////////////////////////////////////////////////
 
#include <nds.h>
#include "reset_patch_bin.h"
#include "../../share/ipctool.h"
#include <string.h>
void zeroMemory(void* addr,int count)
{
    static u32 intidata;
    intidata=0;

    swiFastCopy( (void*)(&intidata), addr, (count>>2) | COPY_MODE_WORD | COPY_MODE_FILL);
}

static void prepairReset()
{
    powerON(POWER_SOUND);
    //reset DMA
    zeroMemory( (void *)0x40000B0, 0x30 );
    REG_IME = IME_DISABLE;
    REG_IE = 0;
    REG_IF = ~0;
}

void VblankHandler(void) 
{
}


int main(int argc, char ** argv) {
    rtcReset();
		powerOFF(POWER_SOUND);
		SOUND_CR = 0;
  	readUserSettings();
    irqInit();
    irqSet(IRQ_VBLANK, VblankHandler);
    irqEnable(IRQ_VBLANK);
    IPC_ARM9 = IPC_MSG_ARM7_READY;
    while( true )
    {
        swiWaitForVBlank();
        vu32 ipc_msg = IPC_ARM9;
        switch( ipc_msg )
        {
            case IPC_MSG_ARM7_REBOOT:
            prepairReset();
            void(* runreset)(void);
						memcpy( (char *)0x23fc000,reset_patch_bin,reset_patch_bin_size );
						runreset=(void(*)(void))0x23fc000;
						runreset();
            break;
        		default:
            {}
        }
    }
}
