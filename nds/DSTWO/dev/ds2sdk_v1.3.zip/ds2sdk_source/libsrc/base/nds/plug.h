#ifndef __PLUG_H__
#define __PLUG_H__

extern void run_plugin(void);

extern char* get_gba_file(void);

#endif //__PLUG_H__
