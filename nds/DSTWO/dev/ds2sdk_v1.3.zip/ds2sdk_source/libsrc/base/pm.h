#ifndef __PM_H__
#define __PM_H__

//There are 14 levels, 0 to 13, 13 level have the highest clocl frequence
extern int ds2_setCPUclocklevel(unsigned int num);

#endif //__PM_H__

