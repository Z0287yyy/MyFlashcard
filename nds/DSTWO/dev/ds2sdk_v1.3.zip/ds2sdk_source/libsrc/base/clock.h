#ifndef __CLOCK_H__
#define __CLOCK_H__

//print colock frequence CPU
extern void printf_clock(void);

//delay n us
extern void udelay(unsigned int usec);

//delay n ms
extern void mdelay(unsigned int msec);

#endif //__CLOCK_H__

