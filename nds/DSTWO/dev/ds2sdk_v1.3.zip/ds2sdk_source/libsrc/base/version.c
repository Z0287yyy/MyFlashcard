//version.c

static const char _version[]= "0.12beta";

const char* ds2_getVersion(void)
{
	return _version;
}

