//modified by DY 

#include "mmc_config.h"
#include "mmc_protocol.h"
#include "mmc_api.h"
#include "mmc_core.h"

#include <mmc_api.c>
#include <mmc_protocol.c>  
#include <mmc_core.c>
#include "mmc_hardware.c"
#ifndef JZ4740_PAV
//#include <mmc_jz.c> 
#endif  
