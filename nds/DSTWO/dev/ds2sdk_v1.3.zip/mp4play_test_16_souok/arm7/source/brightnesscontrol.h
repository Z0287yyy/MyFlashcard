/*---------------------------------------------------------------------------------


Copyright (C) 2007 Acekard, www.acekard.com

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.


---------------------------------------------------------------------------------*/









#ifndef _BRIGHTNESSCONTROL_H_
#define _BRIGHTNESSCONTROL_H_

#include "pmtool.h"
#include "../../share/ipctool.h"


#define PM_NDSLITE_ADR (4)
#define PM_NDSLITE_ISLITE BIT(6)
#define PM_NDSLITE_BRIGHTNESS(x) ((x & 0x03)<<0)
#define PM_NDSLITE_BRIGHTNESS_MASK (PM_NDSLITE_BRIGHTNESS(3))


inline void setBrightness( u8 level )
{
    u8 data = PM_ReadRegister(PM_NDSLITE_ADR);
    if( 0 == (data & PM_NDSLITE_ISLITE) ) // this is not a DS Lite machine
        return;

    data &= ~PM_NDSLITE_BRIGHTNESS_MASK;
    data |= PM_NDSLITE_BRIGHTNESS(level);
    PM_WriteRegister(PM_NDSLITE_ADR,data);
}

inline u8 getBrightness()
{
    u8 data = PM_ReadRegister(PM_NDSLITE_ADR);
    if( 0 == (data & PM_NDSLITE_ISLITE) ) // this is not a DS Lite machine
        return 0;

    data &= PM_NDSLITE_BRIGHTNESS_MASK;
    return data;
}


#endif//_BRIGHTNESSCONTROL_H_
