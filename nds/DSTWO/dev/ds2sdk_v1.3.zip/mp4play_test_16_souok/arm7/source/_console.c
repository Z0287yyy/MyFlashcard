
#include "_console.h"

#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#include "../../share/ipctool.h"



void _consolePrintf(const char* format, ...)
{
  char strbuf[256];
  
  va_list args;
  
  va_start( args, format );
  vsnprintf( strbuf, 255, format, args );
  _consolePrint(strbuf);
}


void _consolePrint(const char* pstr)
{
    int i,j,k;
    //strcpy((char*)(arm7strbeginaddr ),pstr );
    //arm7strchange = 1;
    //return;

    j=strlen(pstr);
    i = arm7strwrite - arm7strread ;
    if ((i != 0) && (i &arm7strindexmask) ==0)//full
    {

    }
    else
    {
        k = arm7strindex;
        if ((k>(arm7strbeginaddr + arm7strlen))||(k<arm7strbeginaddr))
        {
            k=arm7strbeginaddr;
        }
        *(vu32*)(arm7strindexaddr +  ((arm7strwrite & arm7strindexmask) * 4)) = k;
        strcpy((char*)(k),pstr );
        arm7strindex = k + j + 2;
        arm7strwrite++;

        //arm7strchange = 1;
    }


}
