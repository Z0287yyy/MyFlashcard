
#ifndef _console_h
#define _console_h

#include <nds.h>
#ifdef __cplusplus
extern "C" {
#endif
extern void _consolePrint(const char* pstr);
extern void _consolePrintf(const char* format, ...);

#ifdef __cplusplus
}
#endif


// request GBA cart owner for ARM7



#endif
