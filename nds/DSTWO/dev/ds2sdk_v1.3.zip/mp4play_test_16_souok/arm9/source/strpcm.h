
#ifndef strpcm_h
#define strpcm_h

#include <NDS.h>
#include "../../IPC6.h"

//extern vu64 DPGAudioStream_SyncSamples;
//extern u32 DPGAudioStream_PregapSamples;

//extern volatile bool VBlankPassedFlag;
//extern volatile u32 VBlankPassedCount;

//extern volatile bool strpcmRequestStop;

//extern volatile bool strpcmRingEmptyFlag;

//extern volatile u32 strpcmRingBufReadIndex;
//extern volatile u32 strpcmRingBufWriteIndex;
//#define strpcmRingBufWriteIndex audio_buf_write
//#define strpcmRingBufReadIndex audio_buf_read

extern s16 *strpcmRingLBuf;
extern s16 *strpcmRingRBuf;

//extern void InterruptHandler(void);
extern void InitAudio(void);

extern void strpcmStart(void);
extern void strpcmStop(void);

#define strpcmVolumeMax (96)

extern void strpcmSetVolume64(int v);
extern int strpcmGetVolume64(void);

//extern void VBlank_AutoFlip_Enabled(void);
//extern void VBlank_AutoFlip_Disabled(void);


//extern u32 audio_buf[5];
//extern u32 audio_buf_write;
//extern u32 audio_buf_read;
//extern u32 audio_enable;


extern u32 audio_Samples;
extern u32 audio_len;
extern u32 audio_Rate;
extern u32 audio_Channels;
extern EstrpcmFormat audio_Format;

#define CODE_IN_ITCM __attribute__ ((section (".itcm")))

#endif
