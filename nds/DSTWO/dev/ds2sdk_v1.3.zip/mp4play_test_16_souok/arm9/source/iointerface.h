#ifndef IO_interface_H
#define IO_interface_H
u32 cardexitemode(void) ;
u32 cardcommand_r4(u8 cmd,u32 address,u32 data) ;
u32 cardcommand_w4(u8 cmd,u32 address,u32 data) ;
void cardcommand_r512(u8 cmd,u32 address,u32 buf) ;
void cardcommand_w512(u8 cmd,u32 address,u32 buf) ;
void cardcommand_r512n(u8 cmd,u32 address,u32 buf,int len,u32 cpu_callback,int retdata) ;
void cardcommand_w512n(u8 cmd,u32 address,u32 buf,int len) ;
u32 cardcommand_r4_key(u8 cmd,u16 x,u16 y,u16 key,u8 br ) ;
//extern int nds_card_isrun;
	#define min(x, y)	(((x)<(y))?(x):(y))
	#define max(x, y)	(((x)>(y))?(x):(y))
extern u32 get(void);
extern u32 r4_delay;
extern u32 w4_delay;
extern u32 r512_delay;
extern u32 w512_delay;

extern u32 cardcommand_r4_num(u8 cmd,u32 w_num,u32 r_num,u8 flag) ;

u32 cardcommand_r4_rtc(u8 cmd,u32 address) ;

u32 cardexitemode(void) ;

int check_fpga_1(void);
int check_fpga_2(void);
int read_set_512(u32 buf);

//lhm test
u32 read_fifo_state();
void clear_fifo_state();


extern u32 buffer_D[128];
extern int buffer_D_offset;
extern int debug_sw;

#endif	
