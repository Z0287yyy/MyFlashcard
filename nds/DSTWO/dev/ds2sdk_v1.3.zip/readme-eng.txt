1 What is the ds2sdk?

The ds2sdk is an interface of application layer and driver layer.
It's collection of GCC compiler, ds2 hardware driver library, 
some open source library and an example.
It's released to help software lovers to develop program which run on DSTWO.

2 What the ds2sdk can be used to do?

ds2sdk can be seen as a multimedia development kit. Hardware layer mainly provides audio 
and video transmission function. By ds2sdk upper layer interface, you can transfer 
audio data and video data to NDS, the same, you can put NDS hardware information 
and real-time clock information back to the upper application. So, if you're a software 
enthusiast, depending on ds2sdk, all audio and video related things, you can try to do.
For example, you can develop or transplant your own reading software by ds2sdk, 
or you thought that the official iReader has room for improvement, you can make improvement for it
(by the way, the latest version of the iReader source will be fully public released).
You can transplant, or improve the relevant simulator, or do your own home-made software, such as 
MP3 players, MPLAYER player. You can even make your own game if you wish. In short, if you are a software enthusiast, 
ds2sdk gives you a stage.

3 How to use the ds2sdk?

In order to use ds2sdk, you need to do the following things:
( 1 ) Setup development environment, include linux environment and cross-compiling environment.
( 2 ) Your application program is required the entry: ds2_main(), ds2_main() is the same as the function of main() 
      in the general program.
( 3 ) Related hardware and software initialization(Including video, audio, input, output devices and so on): 
      by the function ds2io_init() or function ds2io_initb() to complete.
( 4 ) Initialize the console: the function ConsoleInit() to complete.
( 5 ) Initialize file systems: by function fat_init () to complete. 
      This file system can only read and write SD card in DSTWO.
( 6 ) Enter the user main program, hence, the control has given to the user application program.

For example: (NOTE: ds2sdk's example can refer to the specific program)

void ds2_main(void) //( 2 )
{
	//( 3 ) Initial video and audio and other input and output
	ds2io_init(1024); 

	//( 4 ) Initial console for printf funciton
	ConsoleInit(WHITE_COLOR, BLACK_COLOR, UP_SCREEN, 10);

	//( 5 ) Initial file system
	 fat_init();

	//( 5 ) go to user main funtion
	main(0, 0);
}

In the user application program, you need to call the following function to complete the transfer of audio and video:

audio:

ds2_checkAudiobuff()//check how many buffer buffers are occupied, return the numbers of occupied buffer
ds2_getAudiobuff()//get the audio buffer address
ds2_updateAudio()//flush audio data from buffer to ds2io layer 

video:

ds2_flipScreen() //update video data from buffer to screen


4 How to setup development environment of the ds2sdk?
Linux operation system are required to build the cross-comiling evironment.
If your computer's operating system is just linux, that is best.
But now the situation is that many program developers may be working on Windows. How to do it?
Fortunately, there are many ways to simulate linux environment on Windows.
CYGWIN and VM(virtual Machine) technology can do this. CYGWIN employ some special DLL to enable Linux program 
run on Windows, it require fewer disk space and memory space, but the compability may be not the best. So, 
Cygwin is not recommended. The most effective method is to install VM on Windows, for example, VMware Workstation and
VirtualBox. Although they take up much CPU and memory resources and hard disk space more than CYGWIN, 
but the compatibility is better, you will encounter problems as little as possible. I personally recommend 
the use of VMware Workstation. Here we setup a linux environment by VMware Workstation 6 and Fedora 9.


5 How to compile the ds2sdk example?

After you have setuped linux environment, and you have download the ds2sdk development kit from internet, now,
how to build cross-compiling environment and how to compile the example of ds2sdk? You need to setup shared folders of VM(
about the problem of VMware Workstation's shared folders, different versions of VMware Workstation have different method, 
we are not to introduce one by one here) so that the system in VM could access the ds2sdk development kit, or you can copy
directly ds2sdk development kit to your linux operating system in VM, then you decompress ds2sdk to your computer. For example, 
ds2sdk directory on ~/, the work directory is ~/opt, , OS is Fedora, commands as following:

mkdir -p ~/opt
cd ~/opt
tar xjf ~/ds2sdk/gcc/mipsel-4.1.2-nopic.tar.bz2
export PATH=$PATH:~/opt/mipsel-4.1.2-nopic/bin

In fact, enter ds2sdk directory, just: make. the makefile will decompress
compiler to ~/opt directory and compiling the open source library libds2a.a and
example files.


6 Compared with the previously released SDK, What is the difference of this release SDK?
 
 The release of the SDK contains the biggest bright spot is that the underlying hardware code, also that is source code of libds2b.a,
 specifically, JZ and FPGA / NDS communications source code. I think the part is the SDK owners who most want to see.
 The only regret is that you can not see, can not modify the FPGA program, because of the need to maintain compatibility, 
 so the FPGA program will not be easily altered. However, the space left for us has been great. For example, with the NDS program, 
 if interested, you can improve DS2 data transfer, or release of more robust, more practical, and operational SDK. 
 Also, you can develop DS2 Linux with this release of the SDK, it may be tempting to many people, and the long-awaited thing.