How to use:
copy the dstwoupdate.dat file to the root of microsd card, then upgrade it.
We suggest you to upgrade it on a DS console or never upgraded console.

2013-12-11
DSTWO Fireware v1.23 test Support 3DS v7.0.0-13X

2013-09-14
DSTWO Fireware v1.23 test Support 3DS v6.3.0-12x

2013-08-13
Remove some redundant data

2013-08-08
FLASH program optimized to read

2013-08-07
DSTWO Fireware v1.21
Fixed for 3DS 6.2.0.12x

2013-07-24
DSTWO Fireware v1.20 test Support 3DS ver6.1.0.12x

2013-06-18
DSTWO Fireware v1.20
Fixed for 3DS 6.0.0.11x

2013-03-26
DSTWO Fireware v1.19 test Support 3DS ver5.0.0-11x

2012-12-05
DSTWO Fireware v1.19
Fixed for 3DS ver4.5.0-10x

2012-09-22
DSTWO Fireware v1.18
Fixed for 3DS ver4.4.0-10x

Update: 2012-07-25
1.17 firmware upgrade support for 3ds 4.3.0-10x system

Update: 2012-06-28
1.16 firmware upgrade support for 3ds 4.2.0-9x system

Update: 2012-04-25
1.15 firmware upgrade support for 3ds v3.0.0.7x system

Update: 2011-11-7
1.13 firmware upgrade support for 3ds v2.2.0-4J system & Fixed Mario 3DS

Update: 2011-6-9
1.12 firmware upgrade support for the 3ds v2.0 system

Update: 2011-5-12
the support for the latest NDSI 1.4.2 (Chinese to 1.4.3) system

DSTWO EOS v1.11 Update: 2011-3-9
1, Updated to v1.11 EOS. Added AutorunLastRom function, you can turn on/off it in the setting option of game select menu. You can run your last played game directly by selecting "DS_GAME" in the plugin menu after turned on this function. If you want to enter game select menu after turned on this function, please hold on B to select DS_GAME plugin.
2, Fixed some Japanese letters can't be recognized.


update��2011-3-3
1, Added a system11.dat file which is a patch file for N3DS under the _dstwo folder.
2, Fixed the lag bug under patch mode for #1404-Mogitate Tingle No Barairo Rupee Land(J)



Note: This is version 1.09 OS. Some New DSTWO carts have no fireware, you need to write in it by yourself before using. This is the way:

For NDSi/NDSiXL/NDSiLL:
1, copy the correct _dstwo folder and ds2boot.dat file to the root of your microsd card.
2, insert DSTWO into your console. Boot the console, dont turn off it untill you see the DSTWO cart LOGO(the logo of Fish Tycoon, maybe need about 1 minute). Then re-boot your console.

For NDS/NDSL:
1, copy the correct _dstwo folder and ds2boot.dat file to the root of your microsd card.
2, insert DSTWO into your console. Boot the console, then re-boot when you entered the menu of NDS.

DSTWO EOS v1.09 Update: 2011-01-22
1. Fixed Hello Kitty Big City Dreams(E)
2. Fixed Battle of Giants: Mutant Insects(U)
3. Fixed Bleach Dark Souls(U)
4. Fixed Real-Time-Cheat display bug for some games (include "0" in their crc32)
5. Fixed Real-Time-Guide display bug for some games when your named RTG file as different letter case with rom file
6. Fixed the GBA union for Rockman(#0484) and Pokemon(#0026)
7. Fixed the bug for some homebrews which use (__system_argv), like "MyNitro"




2011-1-13
1, fixed real-time-cheat cant display for some games which contain "0" in their crc32
2, fixed real-time-guide cant display for some games
----------------------------------------------------------
2011/01/12
Fixed the GBA union for Rockman(#0484) and Pokemon(#0026)
----------------------------------------------------------
2010/12/22
Fixed the downloadplay issue for some games
----------------------------------------------------------
2010/12/17
We forgot to add the anti-crash codes for EUR/USA version of Castlevania: Portrait Of Ruin
Added it now :p
----------------------------------------------------------
2010/11/24
We solve low-speed card problem for MvD(U) yesterday. 
But we found u may get a black screen @stage6-2, so we updated again.
----------------------------
2010/11/23
add a card reading function patch
MvD(U) should work on almost slow cards now. 

----------------------------
2010/11/22
Still some slow cards users cant run Mario vs Donkey Kong: Mini-land Mayhem! (U), so we improved the card read speed again.
We had tested with some microsd cards we have, works on all of them. 
----------------------------
2010/11/18
We saw there are still some users report Mario vs Donkey Kong: Mini-land Mayhem! (U) does not work with the patch of 16th
Maybe their microsd card is too slow, so we set the card speed to the max for Anti-Piracy check. 
----------------------------
2010/11/16
Fixed bugs of Mario vs Donkey Kong: Mini-land Mayhem! (U)
----------------------------
2010/11/13 
Fixed New Carnival Funfair Games(EUR) with PATCH mode.

Update: 2010-10-21
1, Fixed file system (Fixed the crash bug when filename is less than 8 letters and there is space in it)
2, Fixed save bugs of Summon Night(J) & Summon Night 2(J)
3, Fixed crash bug of Pokemon Black connection
4, Fixed touch bug of Real Time Menu

update: 2010-09-28
1, Fixed Rabbids Go Home
2, Supports V1.4.2C/V1.4.1J/V1.4.1U/V1.4.1E Fireware
3, Save wirte/read speed up
4, Fixed the bug of some cheats cant be shown in Real-Time menu
5, Fixed a save files recognise mistake bug

Update��2010-09-20
DSTWO Compatible (DSi firmware 1.4.1)

Update��2010-09-04
1, Fixed the unstable crush bug in game (added a check to check if the card is reading busy)
2, Added a simple hotkey mode. 
Full hotkey mode is the same as the in-game hotkey mode before. But in-game menu does not work with some very special games (like Mario RPG 3) before, so we had added a simply hotkey mode, you can enter in-game menu by simply hotkey mode, but Real-Time-Save&Real-Time-Load dont work, other functions work.
You can set the hotkey in the start menu of game browser windows.
3, Use hardware mode to emulate the special command of pokemon games.

update: 2010-08-21
1, Fixed the crush bug of Brain Age Series
2, Fixed the crush bug of Animal Crossing Chinese translated version.
3, Added the rumble, browser funcation(set in the system menu) for slot-2 series, supports SC slot-2 carts and 3in1 cart.
4, optimized read speed.
5, added reset hotkey(Select button) for the Real-Time menu.

update :2010-08-05
1. Fixed 0396, 5140 Galaxy Racers reading save data error problem.
2. Fixed 0856 Bleach 2nd can not save problem.
3. Fixed 5116 Keshikasu Japanese version (clean mode)
4. Fixed the cheat code blank list problem in some games. 
5. Added GBA linkage function.
Q: How to use GBA linkage function?
A: Usage: NAME.nds, NAME.nds.gba, NAME.nds.gba.sav. These three files are DS game file, GBA game file, GBA game save. NAME which can be user defined. This feature is selected by the user to open, choose the interface in the  start menu, select System Settings option.
6. Added the WII linkage functions.
7. The main menu by using cyclic mode
8. Added support ez3 in 1,  superCard lite, superCard MINI SD, superCard SD, superCard CF
9. Update Korean language package
10. Added prevent halt in Castlevania: Portrait of Ruin.

Update: 2010-07-02
1. Fixed 2971 Star Wars Clone Wars.
2. Fixed save corrupt problem of 0856 - Bleach DS 2nd - Kokui Hirameku Requiem (JP) (WRG).
3. Enable to modify the desktop icon "DS_GAME", just edit the dstwo_game.ini file (it's in "_dstwoplug" folder, edit the same way as other plug-ins).
4. Added a sort type, text list.
5. Fixed a bug which touch invalid of text part in file list.
6. Fixed reset in the game return to desktop, switch to game list.
7. Fixed the amount of shin limitation.
8. Changed desktop icon from cycle show to single way, and removed the space plug-in icon .
9. Fixed the real-time menu splash screen problem.
10. Enhanced homebrew compatibility.
11. Fixed Eigokoro Kyoushitsu DS(J) The save file size should be 64Mb, please del the old 512kb save file of it

update :2010-06-01
1, Update the file system, remove checking storage space function to improve reading speed.
2, Added system file protection, user could not operate on system files to avoid system corrupt.
3, Fixed ReadTime Save display time error bug.
4, Fixed save problem, when the patch database save size is different from customer save size setting, will keep customer save size. 
5, Fixed a cheat code bug. Sometimes, the cheat code does not display 

6, Fixed GameWatch Games Collection, RPG tools. 
   1222 - Archime DS (J)
   2360 - LOL (U)
   2645 - Bakushow
7, Fixed downplay function.
8, Added DSTWO provide Soft-Reset function for Homebrew.  Any homebrew software run ��_dstwo/reset2desktop.nds�� file can return to DSTWO desktop.

update:2010-05-22
Fix "Made in Ore"&"RPG Tool DS"
Fix "4951 Daigasso! Band Brothers",The save is normal now
Fix "4952 Prince of Persia(Black screen Error)",If you want to play,Premise is clean mode
Increase capacity detect in disk for enter the game,Avoid roms generate the bad damage the game system