
Image Viewer Version 0.5

gba_nds_fat by Chishm
ZLIB (C) 1995-2004 Jean-loup Gailly and Mark Adler
DevKitARMr19b + libnds-20060719

----------

MakeNDSROM.exe
The NDSROM file for each adaptor is made. 

img2ipk.exe
Two or more images are packaged. The thumbnail image is made.

----------

Please execute 'MakeNDSROM.exe'. And, please copy the NDSROM file for your adaptor onto media.

The conversion work is necessary for the picture file.

Please switch from "CustomJpeg mode" to "ZLIB mode" for the high-resolution. The file size is large.

----------

Double screen (open wide) mode can be used when there is a cache memory.
The scroll quickens as for single screen mode.
'M3Perfect/M3Professional/CF/SD' can be used for the cache memory.
'The cartridge of enhancing the memory of DS browser' can be used for the cache memory.
There is a memory test tool in the fourth page of the slide show option.

----------

'Up/Down/Left/Right/SholderL' and 'A/B/X/Y/SholderR' are the same functions.
All work can be basically done with the icon and the touch panel.

IPK file selection mode.

Icon Left up : Change backlight brightness.
Up/Down button : Move cursor.
SholderL button : Decision. (to thumbnail mode)
Start button : Slide show beginning.

Thumbnail mode.

Icon left up : Change backlight brightness.
Icon right up : Return to IPK file selection mode.
Icon center up : Toggle switch of vertical and horizontal.
Icon center down : Moves to the slide show setting mode.
Up/Down/Left/Right button : Move cursor.
SholderL button : Decision. (to view mode)
Start button : Moves to the slide show setting mode.
Select button : Return to IPK file selection mode.

Slide show setting mode.

Start button : Slide show beginning.

View mode.

Icon left up : Change backlight brightness.
Icon right up : Return to thumbnail mode.
Icon left down : Back to previous image.
Icon right down : Next to the subsequent page.
Icon center left up : Toggle switch of vertical and horizontal.
Icon center right up : Toggle switch of 'Single screen and preview mode' and 'Double screen mode'. (Request use cache memory.)
Icon center down : The reduction rate is changed.
Up/Down/Left/Right button : Move cursor.
Start button : Moves to the slide show setting mode.
SholderL button : The enhancing command menu is opened.
SholderL + Up button : Return to thumbnail mode.
SholderL + Left button : Back to previous image.
SholderL + Right button : Next to the subsequent page.
SholderL + Select button : Start position menu is opened.

