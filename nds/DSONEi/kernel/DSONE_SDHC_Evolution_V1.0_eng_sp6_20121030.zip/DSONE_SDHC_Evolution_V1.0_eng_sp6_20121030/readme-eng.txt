2012-10-30
Fixed for 
6132 �C Pokemon: Weisse Edition 2 (GER) 
6130 �C Pokemon: Schwarze Edition 2 (GER) 
6129 �C Pokemon: Versione Nera 2 (ITA)
6127 �C Pokemon: Versione Bianca 2 (ITA)
6128 �C Pokemon: Edicion Blanca 2 (SPA)
6109 �C Pokemon: Edicion negra 2 (SPA)
6126 �C Pokemon: Version Blanche 2 (FR)Blanche
6125 �C Pokemon: Version Noire 2 (FR)
6110 �C Pokemon: Black Version 2 (USA)
6108 �C Pokemon: White Version 2 (USA)
6044 �C Pokemon: White Version 2 (JPN)
6045 �C Pokemon: Black Version 2 (JPN)
----------------------------------------------------------
2012-08-03
Fixed for Bakuman: The Road to Becoming a Manga Artist
----------------------------------------------------------
2012-06-26
Fixed for Pokemon Black2��Pokemon White2
----------------------------------------------------------
2012-06-13
Fixed for  Captain America: Super Soldier (U)
Fixed for  Captain America: Super Soldier (E)
----------------------------------------------------------
2012-05-21
Fixed for.. 
5782 -�Ω`��ȿ̤ι��� �F��ɭ��ħŮ
5811- All Kamen Rider: Rider Generation
5994 - Pokemon + Nobunaga no Yabou
0616 - Meitantei Conan - Kakokara no Zensou Kyoku
----------------------------------------------------------
2011-12-13
Fixed for Metal Max 2 reloaded (J)
----------------------------------------------------------
2011-11-30
Fixed for Power Rangers Samurai(U)
----------------------------------------------------------
2011-11-21
Fixed for One Piece Gigant Battle 2(J)
----------------------------------------------------------
2011-11-8
Fixed for Camping Mama Papa(U)
----------------------------------------------------------
2011-9-23
Fixed Kirby Mass Attack(U)
----------------------------------------------------------
2011-9-8
Fixed for some Pokemon B/W modified version
----------------------------------------------------------
2011-9-3
New patch for Atsumete Kirby(Chinese)!
----------------------------------------------------------
2011-7-18
1, Fixed: Captain America: Super Soldier(E)
----------------------------------------------------------
2011/04/27
1, Fixed: Ace Attorney DS Homebrew crash bug
2, Fixed: NitroTracker-v0.4 crash bug
3, Fixed: Chinese Translated version pokemon black/white crash bug when battles with other players. 
----------------------------------------------------------
2011/03/11
Fixed: Pokemon White/Black (Eur)(Ger)(Spa)
----------------------------------------------------------
2011/01/12
Fixed the GBA union for Rockman(#0484) and Pokemon(#0026)
----------------------------------------------------------
2010/12/22
Fixed the downloadplay issue for some games
----------------------------------------------------------
2010/12/17
We forgot to add the anti-crash codes for EUR/USA version of Castlevania: Portrait Of Ruin
Added it now :p
----------------------------------------------------------
2010/11/24 Again
We solve low-speed card problem for MvD(U) before. 
But we found u may get a black screen @stage6-2, so we updated again.
----------------------------------------------------------
2010/11/24
Improved the patch for Mario vs Donkey Kong: Mini-land Mayhem! (U), improved card reading mode for games.
----------------------------------------------------------
2010/11/13 
Fixed New Carnival Funfair Games(EUR) with PATCH mode.