moonshell 1.7x :please copy the reset.mse into moonshl\plugin
moonshell 2.x  :please copy the IPLY.nds into MOONSHL2\RESETMSE