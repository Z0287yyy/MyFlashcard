Update 2010.08.12
iPlayer GBA Emulator ver1.1
Added support popular cheat code file *.cht.
Fixed some GUI bugs
Added turn off down screen save power
Fixed some firmware bugs.

FAQ
Q: How to install GBA emulator into iPlayer?
A: 1. Make sure the fireware and OS of your iPlayer is the lastest version
     2. Copy the "plugins" folder into /_system/

Q: How to boot GBA emulator from iPlayer?
A: Method 1:
    1. Enter "homebrew" menu.
    2. Find the GBA.PLG file and press A button.
    Method 2:
    Select a *.GBA file to run.

Q: How to select a GBA game to run?
A: 1. Press X in game to show menu.
    2. Select New button.
    3. Press A button enter folder, press B button back to up folder.
    4. Y button mean return.

Update 2009.09.12
iPlayer GBA Emulator ver1.0
UI:sitesky

- Video & Audio
Graphic size: Original size
Game fast forward: default is off. The frame skip level will be set into 9 when you turn on it, then you can play games with the fastest speed
Frame skip type: default is auto, you can set it into Manual, then you can set the frame skip level
Frame skip level: the higher level the faster game speed
Sound switch: switch on/off the sound

- Save State
Write game state: limited 32 slots
Read game state: read saves with the screenshot and date

- Cheats
Supports Pro Action Replay/Gameshark codes.
Put the cheat files into /Gamecht/

- Tools
Screen snapshot: 
Save the pics as .BMP format into /Gamepic/
Supports auto display pics

- Others
Supports Auto standby
Supports CHT/ENG

Note:
Suggest to format microsd card into FAT format, it's faster :p


FAQ
Q: How to install GBA emulator into iPlayer?
A: 1. Make sure the fireware and OS of your iPlayer is the lastest version
     2. Copy the "plugins" folder into /_system/

Q: How to boot GBA emulator from iPlayer?
A: Method 1:
    1. Enter "homebrew" menu.
    2. Find the GBA.PLG file and press A button.
    Method 2:
    Select a *.GBA file to run.

Q: How to select a GBA game to run?
A: 1. Press X in game to show menu.
    2. Select New button.
    3. Press A button enter folder, press B button back to up folder.
    4. Y button mean return.


